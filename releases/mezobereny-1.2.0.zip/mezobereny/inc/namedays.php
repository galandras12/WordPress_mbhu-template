<?php
/**
 * Magyar névnaptár - a mezobereny.hu fejlécében látható
 * "Ma ...  Magdolna napja van" jellegű sor kiszolgálásához.
 *
 * FONTOS: ez a lista a széles körben ismert, közkincs magyar névnap-naptár
 * alapján készült, legjobb tudásunk szerint. Mivel több naptárkiadás
 * kis mértékben eltér egymástól, telepítés után érdemes soronként
 * ellenőrizni/pontosítani a lenti tömböt (hónap-nap => névnap).
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function mezobereny_namedays_list() {
	return array(
		'01-01' => 'Fruzsina', '01-02' => 'Ábel', '01-03' => 'Genoveva, Benjámin', '01-04' => 'Titusz, Leona',
		'01-05' => 'Simon', '01-06' => 'Boldizsár', '01-07' => 'Attila, Ramóna', '01-08' => 'Gyöngyvér',
		'01-09' => 'Marcell', '01-10' => 'Melánia', '01-11' => 'Ágota', '01-12' => 'Ernő',
		'01-13' => 'Veronika', '01-14' => 'Bódog', '01-15' => 'Lóránt, Loránd', '01-16' => 'Gusztáv',
		'01-17' => 'Antal, Antónia', '01-18' => 'Piroska', '01-19' => 'Sára, Márió', '01-20' => 'Fábián, Sebestyén',
		'01-21' => 'Ágnes', '01-22' => 'Vince, Artúr', '01-23' => 'Zelma, Rajmund', '01-24' => 'Timót',
		'01-25' => 'Pál', '01-26' => 'Vanda, Paula', '01-27' => 'Angelika', '01-28' => 'Károly, Karola',
		'01-29' => 'Adél', '01-30' => 'Martina, Gerda', '01-31' => 'Marcella',

		'02-01' => 'Ignác, Brigitta', '02-02' => 'Karolina, Aida', '02-03' => 'Balázs', '02-04' => 'Ráhel, Csenge',
		'02-05' => 'Ágota, Ingrid', '02-06' => 'Dóra, Dorottya', '02-07' => 'Rómeó, Tódor', '02-08' => 'Aranka',
		'02-09' => 'Abigél, Alex', '02-10' => 'Elvira', '02-11' => 'Bertold, Marietta, Dezső', '02-12' => 'Lívia, Lídia',
		'02-13' => 'Ella, Linda', '02-14' => 'Bálint, Valentin', '02-15' => 'Kolos, Georgina', '02-16' => 'Julianna, Lilla',
		'02-17' => 'Donát', '02-18' => 'Bernadett', '02-19' => 'Zsuzsanna', '02-20' => 'Aladár, Álmos',
		'02-21' => 'Eleonóra', '02-22' => 'Gerzson', '02-23' => 'Alfréd', '02-24' => 'Mátyás',
		'02-25' => 'Géza', '02-26' => 'Edina', '02-27' => 'Ákos, Bátor', '02-28' => 'Elemér', '02-29' => 'Szökőnap',

		'03-01' => 'Albin', '03-02' => 'Lujza', '03-03' => 'Kornélia', '03-04' => 'Kázmér',
		'03-05' => 'Adorján, Adrián', '03-06' => 'Leonóra, Inez', '03-07' => 'Tamás', '03-08' => 'Zoltán',
		'03-09' => 'Franciska, Fanni', '03-10' => 'Ildikó', '03-11' => 'Szilárd', '03-12' => 'Gergely',
		'03-13' => 'Krisztián, Ajtony', '03-14' => 'Matild', '03-15' => 'Kristóf', '03-16' => 'Henrietta',
		'03-17' => 'Gertrúd, Patrik', '03-18' => 'Sándor, Ede', '03-19' => 'József', '03-20' => 'Klaudia',
		'03-21' => 'Benedek', '03-22' => 'Beáta, Izolda', '03-23' => 'Emőke', '03-24' => 'Gábor, Karina',
		'03-25' => 'Irén, Irina', '03-26' => 'Emánuel', '03-27' => 'Hajnalka', '03-28' => 'Gedeon, Johanna',
		'03-29' => 'Auguszta', '03-30' => 'Zalán', '03-31' => 'Árpád, Benő',

		'04-01' => 'Hugó', '04-02' => 'Áron', '04-03' => 'Buda, Richárd', '04-04' => 'Izidor',
		'04-05' => 'Vince', '04-06' => 'Vilmos, Bíborka', '04-07' => 'Herman', '04-08' => 'Dénes',
		'04-09' => 'Erhard', '04-10' => 'Zsolt', '04-11' => 'Leó, Szaniszló', '04-12' => 'Gyula',
		'04-13' => 'Ida', '04-14' => 'Tibor', '04-15' => 'Anasztázia, Tas', '04-16' => 'Csongor',
		'04-17' => 'Rudolf, Kiara', '04-18' => 'Andrea, Ilma', '04-19' => 'Emma', '04-20' => 'Tivadar',
		'04-21' => 'Konrád', '04-22' => 'Csilla, Noémi', '04-23' => 'Béla', '04-24' => 'György',
		'04-25' => 'Márk', '04-26' => 'Ervin', '04-27' => 'Zita, Mariann', '04-28' => 'Valéria',
		'04-29' => 'Péter', '04-30' => 'Katalin, Kitti',

		'05-01' => 'Fülöp, Jakab', '05-02' => 'Zsigmond', '05-03' => 'Tímea, Irma', '05-04' => 'Mónika, Flórián',
		'05-05' => 'Györgyi', '05-06' => 'Ivett, Frida', '05-07' => 'Gizella', '05-08' => 'Mihály',
		'05-09' => 'Gergely', '05-10' => 'Ármin, Pálma', '05-11' => 'Ferenc', '05-12' => 'Pongrác',
		'05-13' => 'Szervác, Imola', '05-14' => 'Bonifác', '05-15' => 'Zsófia, Szonja', '05-16' => 'Mózes, Botond',
		'05-17' => 'Paszkál', '05-18' => 'Erik, Alexandra', '05-19' => 'Ivó, Milán', '05-20' => 'Bernát, Felícia',
		'05-21' => 'Konstantin', '05-22' => 'Júlia, Rita', '05-23' => 'Dezső', '05-24' => 'Eszter, Eliza',
		'05-25' => 'Orbán', '05-26' => 'Fülöp, Evelin', '05-27' => 'Hella', '05-28' => 'Emil, Csanád',
		'05-29' => 'Magdolna', '05-30' => 'Janka, Zsanett', '05-31' => 'Angéla, Petronella',

		'06-01' => 'Tünde', '06-02' => 'Kármen, Anita', '06-03' => 'Klotild', '06-04' => 'Bulcsú',
		'06-05' => 'Fatima', '06-06' => 'Norbert, Cintia', '06-07' => 'Róbert', '06-08' => 'Medárd',
		'06-09' => 'Félix', '06-10' => 'Margit, Gréta', '06-11' => 'Barnabás', '06-12' => 'Villő',
		'06-13' => 'Antal, Anett', '06-14' => 'Vazul', '06-15' => 'Jolán, Vid', '06-16' => 'Jusztin',
		'06-17' => 'Laura, Alida', '06-18' => 'Arnold, Levente', '06-19' => 'Gyárfás', '06-20' => 'Rafael',
		'06-21' => 'Alajos, Leila', '06-22' => 'Paulina', '06-23' => 'Zoltán', '06-24' => 'Iván',
		'06-25' => 'Vilmos', '06-26' => 'János, Pál', '06-27' => 'László', '06-28' => 'Levente, Irén',
		'06-29' => 'Péter, Pál', '06-30' => 'Pál',

		'07-01' => 'Tihamér, Annamária', '07-02' => 'Ottó', '07-03' => 'Kornél, Soma', '07-04' => 'Ulrik',
		'07-05' => 'Emese, Sarolta', '07-06' => 'Csaba', '07-07' => 'Apollónia', '07-08' => 'Ellák',
		'07-09' => 'Lukrécia', '07-10' => 'Amália', '07-11' => 'Nóra, Lili', '07-12' => 'Izabella, Dalma',
		'07-13' => 'Jenő', '07-14' => 'Örs, Stella', '07-15' => 'Henrik, Roland', '07-16' => 'Valter',
		'07-17' => 'Endre, Elek', '07-18' => 'Frigyes', '07-19' => 'Emília', '07-20' => 'Illés',
		'07-21' => 'Dániel, Daniella', '07-22' => 'Magdolna', '07-23' => 'Lenke', '07-24' => 'Kinga, Kincső',
		'07-25' => 'Kristóf, Jakab', '07-26' => 'Anna, Anikó', '07-27' => 'Olga, Liliána', '07-28' => 'Szabolcs',
		'07-29' => 'Márta, Flóra', '07-30' => 'Judit, Xénia', '07-31' => 'Oszkár',

		'08-01' => 'Boglárka', '08-02' => 'Lehel', '08-03' => 'Hermina', '08-04' => 'Domonkos, Dominik',
		'08-05' => 'Krisztina', '08-06' => 'Berta, Bettina', '08-07' => 'Ibolya', '08-08' => 'László',
		'08-09' => 'Emőd', '08-10' => 'Lőrinc', '08-11' => 'Zsuzsanna, Tiborc', '08-12' => 'Klára',
		'08-13' => 'Ipoly', '08-14' => 'Marcell', '08-15' => 'Mária', '08-16' => 'Ábrahám',
		'08-17' => 'Jácint', '08-18' => 'Ilona', '08-19' => 'Huba', '08-20' => 'István',
		'08-21' => 'Sámuel, Hajna', '08-22' => 'Menyhért, Mirjam', '08-23' => 'Bence', '08-24' => 'Bertalan',
		'08-25' => 'Lajos, Patrícia', '08-26' => 'Izsó', '08-27' => 'Gáspár', '08-28' => 'Ágoston',
		'08-29' => 'Beatrix, Erna', '08-30' => 'Rózsa', '08-31' => 'Erika, Bella',

		'09-01' => 'Egyed, Egon', '09-02' => 'Rebeka, Dorina', '09-03' => 'Hilda', '09-04' => 'Rozália',
		'09-05' => 'Viktor, Lőrinc', '09-06' => 'Zakariás', '09-07' => 'Regina', '09-08' => 'Mária, Adrienn',
		'09-09' => 'Ádám', '09-10' => 'Nikolett, Hunor', '09-11' => 'Teodóra', '09-12' => 'Mária',
		'09-13' => 'Kornél', '09-14' => 'Szeréna, Roxána', '09-15' => 'Enikő, Melitta', '09-16' => 'Edit',
		'09-17' => 'Zsófia', '09-18' => 'Diána', '09-19' => 'Vilhelmina', '09-20' => 'Friderika',
		'09-21' => 'Máté, Mirella', '09-22' => 'Móric', '09-23' => 'Tekla', '09-24' => 'Gellért, Mercédesz',
		'09-25' => 'Eufrozina, Kende', '09-26' => 'Jusztina', '09-27' => 'Adalbert', '09-28' => 'Vencel',
		'09-29' => 'Mihály', '09-30' => 'Jeromos',

		'10-01' => 'Malvin', '10-02' => 'Petra', '10-03' => 'Helga', '10-04' => 'Ferenc',
		'10-05' => 'Aurél', '10-06' => 'Brúnó, Renáta', '10-07' => 'Amália', '10-08' => 'Koppány',
		'10-09' => 'Dénes', '10-10' => 'Gedeon', '10-11' => 'Brigitta', '10-12' => 'Miksa',
		'10-13' => 'Kálmán, Ede', '10-14' => 'Helén', '10-15' => 'Teréz', '10-16' => 'Gál',
		'10-17' => 'Hedvig', '10-18' => 'Lukács', '10-19' => 'Nándor', '10-20' => 'Vendel',
		'10-21' => 'Orsolya', '10-22' => 'Előd', '10-23' => 'Gyöngyi', '10-24' => 'Salamon',
		'10-25' => 'Blanka, Bianka', '10-26' => 'Dömötör', '10-27' => 'Szabina', '10-28' => 'Simon, Szimonetta',
		'10-29' => 'Nárcisz', '10-30' => 'Alfonz', '10-31' => 'Farkas',

		'11-01' => 'Marianna', '11-02' => 'Achilles', '11-03' => 'Győző', '11-04' => 'Károly',
		'11-05' => 'Imre', '11-06' => 'Lénárd', '11-07' => 'Rezső', '11-08' => 'Zsombor',
		'11-09' => 'Tivadar', '11-10' => 'Réka', '11-11' => 'Márton', '11-12' => 'Jónás, Renátó',
		'11-13' => 'Szilvia', '11-14' => 'Aliz', '11-15' => 'Albert, Lipót', '11-16' => 'Ödön',
		'11-17' => 'Hortenzia, Gergő', '11-18' => 'Jenő', '11-19' => 'Erzsébet', '11-20' => 'Jolán',
		'11-21' => 'Olivér', '11-22' => 'Cecília', '11-23' => 'Kelemen, Klementina', '11-24' => 'Emma',
		'11-25' => 'Katalin', '11-26' => 'Virág', '11-27' => 'Virgil', '11-28' => 'Stefánia',
		'11-29' => 'Taksony', '11-30' => 'András, Andor',

		'12-01' => 'Elza', '12-02' => 'Melinda, Vivien', '12-03' => 'Ferenc, Olívia', '12-04' => 'Barbara, Borbála',
		'12-05' => 'Vilma', '12-06' => 'Miklós', '12-07' => 'Ambrus', '12-08' => 'Mária',
		'12-09' => 'Natália', '12-10' => 'Judit', '12-11' => 'Árpád', '12-12' => 'Gabriella',
		'12-13' => 'Luca, Otília', '12-14' => 'Szilárda', '12-15' => 'Valér', '12-16' => 'Etelka, Aletta',
		'12-17' => 'Lázár, Olimpia', '12-18' => 'Auguszta', '12-19' => 'Viola', '12-20' => 'Teofil',
		'12-21' => 'Tamás', '12-22' => 'Zénó', '12-23' => 'Viktória', '12-24' => 'Ádám, Éva',
		'12-25' => 'Eugénia', '12-26' => 'István', '12-27' => 'János', '12-28' => 'Kamilla',
		'12-29' => 'Tamás, Tamara', '12-30' => 'Dávid', '12-31' => 'Szilveszter',
	);
}

/**
 * Visszaadja az aktuális (vagy megadott) nap névnapját.
 */
function mezobereny_get_nameday( $date = null ) {
	$date  = $date ? $date : current_time( 'm-d' );
	$names = mezobereny_namedays_list();
	$value = isset( $names[ $date ] ) ? $names[ $date ] : '';
	return apply_filters( 'mezobereny_nameday', $value, $date );
}

/**
 * A fejlécben megjelenő "Ma 2026. július 22. szerda, Magdolna napja van" jellegű sor.
 */
function mezobereny_today_string() {
	$hu_months = array( 1=>'január',2=>'február',3=>'március',4=>'április',5=>'május',6=>'június',7=>'július',8=>'augusztus',9=>'szeptember',10=>'október',11=>'november',12=>'december' );
	$hu_days   = array( 'Sunday'=>'vasárnap','Monday'=>'hétfő','Tuesday'=>'kedd','Wednesday'=>'szerda','Thursday'=>'csütörtök','Friday'=>'péntek','Saturday'=>'szombat' );

	$y = current_time( 'Y' );
	$m = (int) current_time( 'n' );
	$d = (int) current_time( 'j' );
	$day_en = current_time( 'l' );

	$nameday = mezobereny_get_nameday();
	$text = sprintf( 'Ma %d. %s %d. %s', $y, $hu_months[ $m ], $d, $hu_days[ $day_en ] );
	if ( $nameday ) {
		$text .= sprintf( ', %s napja van', $nameday );
	}
	return $text;
}
